(ns sample.core-test
	(:use sample.core)
	(:require [clojure.test :as test])
	)
	